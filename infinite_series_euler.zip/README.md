# infinite_series_euler
Cálculo do número de Euler com series infinitas utilizando técnicas de programação concorrentese o framework Executors
